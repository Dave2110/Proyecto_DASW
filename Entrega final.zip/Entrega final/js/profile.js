function initData() {
  const email = JSON.parse(localStorage.getItem("token")).email;
  const url = `http://localhost:3000/api/users/?email=${email}`;

  let xhr = new XMLHttpRequest();
  xhr.open("GET", url);
  xhr.send(JSON.stringify({ email: email }));
  xhr.onload = function () {
    if (xhr.status != 200) {
      alert(xhr.status + ": " + xhr.statusText);
    } else {
      let user = JSON.parse(xhr.responseText);

      if (user) {
        // Llena cada campo del formulario con los valores recibidos
        document.getElementById("exampleFirstName").value = user[0].name || "";
        document.getElementById("exampleLastName").value =
          user[0].lastName || "";
        document.getElementById("exampleInputEmail").value =
          user[0].email || "";
        document.getElementById("exampleInputPhone").value =
          user[0].phone || "";
        document.getElementById("exampleAddress").value = user[0].address || "";
        document.getElementById("exampleCity").value = user[0].city || "";
        document.getElementById("exampleState").value = user[0].state || "";
        document.getElementById("exampleZip").value = user[0].cp || "";
        document.getElementById("exampleCountry").value = user[0].country || "";
      } else {
        alert("Usuario no encontrado");
      }
    }
  };
  xhr.onerror = function () {
    alert("Error en la solicitud de red.");
  };
}

function putUser() {
  const id = JSON.parse(localStorage.getItem("token"))._id;
  const url = `http://localhost:3000/api/users/${id}`;

  const updatedUserData = {
    name: document.getElementById("exampleFirstName").value,
    lastName: document.getElementById("exampleLastName").value,
    email: document.getElementById("exampleInputEmail").value,
    phone: document.getElementById("exampleInputPhone").value,
    address: document.getElementById("exampleAddress").value,
    city: document.getElementById("exampleCity").value,
    state: document.getElementById("exampleState").value,
    cp: document.getElementById("exampleZip").value,
    country: document.getElementById("exampleCountry").value,
  };

  let xhr = new XMLHttpRequest();
  xhr.open("PUT", url);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.send(JSON.stringify(updatedUserData));
  xhr.onload = function () {
    if (xhr.status != 200) {
      alert(xhr.status + ": " + xhr.statusText);
      alert("Usuario actualizado correctamente");
    } else {
      let user = JSON.parse(xhr.responseText);
      alert("Usuario actualizado correctamente");
    }
  };
  xhr.onerror = function () {
    alert("Error en la solicitud de red.");
  };
}

function deleteUser() {
  const id = JSON.parse(localStorage.getItem("token"))._id;
  const url = `http://localhost:3000/api/users/${id}`;

  let xhr = new XMLHttpRequest();
  xhr.open("DELETE", url, true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.send();

  xhr.onload = function () {
    if (xhr.status != 200) {
      alert(`${xhr.status}: ${xhr.statusText}`);
      alert("Hubo un error al eliminar el usuario.");
    } else {
      localStorage.removeItem("token");
      alert("Usuario eliminado con éxito.");
    }
  };

  xhr.onerror = function () {
    alert("Error en la solicitud de red.");
  };
}

initData();
