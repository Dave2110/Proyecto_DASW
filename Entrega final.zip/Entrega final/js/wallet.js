function initData() {
  const userId = JSON.parse(localStorage.getItem("token"))._id;
  let tabla = document.getElementById("dataTable");
  let url = "http://localhost:3000/api/historial/" + userId;
  const token = JSON.parse(localStorage.getItem("token")).token;

  let xhr = new XMLHttpRequest();
  xhr.open("GET", url);
  xhr.setRequestHeader("content-Type", "application/json");
  xhr.setRequestHeader("x-user-token", token);
  xhr.send();
  xhr.onload = function () {
    if (xhr.status != 200) {
      alert(xhr.status + ": " + xhr.statusText);
    } else {
      tabla.innerHTML = "";
      let historial = JSON.parse(xhr.responseText);
      historial.forEach((item) => {
        const nftId = item.nftId;
        let nftXhr = new XMLHttpRequest();
        let nftUrl = "http://localhost:3000/api/nfts/" + nftId;
        nftXhr.open("GET", nftUrl);
        nftXhr.setRequestHeader("content-Type", "application/json");
        nftXhr.setRequestHeader("x-user-token", token);
        nftXhr.send();
        nftXhr.onload = function () {
          if (nftXhr.status == 200) {
            let nft = JSON.parse(nftXhr.responseText);
            // Crear el elemento HTML para cada NFT con su precio obtenido
            let galleryItem = document.createElement("tr");
            
            const fullDate = item.fecha;
            const dateObject = new Date(fullDate);
            const year = dateObject.getFullYear();
            const month = String(dateObject.getMonth() + 1).padStart(2, "0");
            const day = String(dateObject.getDate()).padStart(2, "0");

            const onlyDate = `${year}-${month}-${day}`;

            galleryItem.innerHTML = `
                <td>${onlyDate}</td>
                <td>${nft.nombre}</td>
                <td>Leonardo Ruiz</td>
                <td>${item.cantidad}</td>
                `;
            tabla.appendChild(galleryItem);
          } else {
            alert(nftXhr.status + ": " + nftXhr.statusText);
          }
        };
        nftXhr.onerror = function () {
          alert("Error en la solicitud de red.");
        };
      });
    }
  };
  xhr.onerror = function () {
    alert("Error en la solicitud de red.");
  };
}

initData();
