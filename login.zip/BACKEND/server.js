"use strict;"
const express = require('express');
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const randomize = require('randomatic');
const cors = require('cors');
mongoose.set('strictQuery', true);

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors({
    methods: ['GET', 'POST', 'DELETE', 'UPDATE', 'PUT', 'PATCH']
}));

/* Conexión con base de datos */
let mongoConnection = "mongodb://admin:nOen8e52JE4xwjN8@ac-a8wsa4s-shard-00-00.ds6xdtn.mongodb.net:27017,ac-a8wsa4s-shard-00-01.ds6xdtn.mongodb.net:27017,ac-a8wsa4s-shard-00-02.ds6xdtn.mongodb.net:27017/?ssl=true&replicaSet=atlas-12ykuz-shard-0&authSource=admin&retryWrites=true&w=majority&appName=Cluster0s";
mongoose.connect(mongoConnection, { useNewUrlParser: true });

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'Error de conexión a la base de datos:'));
db.once('open', () => {
    console.log('Conexión exitosa a la base de datos');
});

/* USER */
let userSchema = mongoose.Schema({
    email: {
        type: String,
        required: true
    },
    pass: {
        type: String,
        required: true
    },
    token: {
        type: String
    }
});

let User = mongoose.model('users', userSchema);

app.get("/api/users", (req, res) => {
    User.find({
        email: { $regex: req.query.email },
    }, function (err, docs) {
        res.status(200);
        res.send(docs);
    });

});

app.post('/api/users', (req, res) => {
    if (req.body.email == undefined) {
        res.status(400);
        res.send("No se agregó email");
        return;
    }
    if (req.body.pass == undefined) {
        res.status(400);
        res.send("No se agregó contraseña");
        return;
    }
    User.find({
        email: req.body.email
    }, function (err, docs) {
        if (docs.length != 0) {
            res.status(400);
            res.send('Email ya registrado');
            return;
        }
        let hash = bcrypt.hashSync(req.body.pass, 10);
        req.body.email = req.body.email.toLowerCase();
        let email = req.body.email;
        let newUser = { email: email, pass: hash };
        let user = User(newUser);

        user.save();
        res.status(200);
        res.send("Usuario agregado con exito");
    });
});

/* LOGIN */
app.post("/api/login", (req, res) => {
    if (!req.body.email) {
        res.status(400);
        res.send("No se agregó email");
        return;
    }
    if (!req.body.pass) {
        res.status(400);
        res.send("No se agregó contraseña");
        return;
    }
    User.find({
        email: req.body.email
    }, function (err, docs) {
        if (docs.length === 0) {
            res.status(401);
            res.send("Email incorrecto");
            return;
        }
        if (!bcrypt.compareSync(req.body.pass, docs[0].pass)) {
            res.status(401);
            res.send("Contraseña incorrecta");
            return;
        }
        let jObject = docs[0];
        if (jObject.token == undefined) {
            jObject.token = randomize('Aa0', '10') + "-" + jObject._id;
            let objectToUpdate = {
                _id: jObject._id,
                email: jObject.email,
                pass: jObject.pass,
                token: jObject.token
            }
            
            User.findByIdAndUpdate(jObject._id, objectToUpdate, { new: true }, (err, doc) => {
                if (err) {
                    res.send(err);
                }
                else {
                    res.status(200);
                    res.send(doc.token);
                    return
                }
            });
        }
        else {
            User.findById(jObject._id, (err, doc) => {
                if (err) {
                    res.send(err);
                }
                else {
                    res.status(200);
                    res.send(doc.token);
                    return;
                }
            });
        }
    });
});

/* AUTH */
function authenticator(req, res, next) {
    let token = req.get("x-user-token");
    if (token) {
        User.find({
            token: token
        }, (err, doc) => {
            if (err) {
                res.send(err);
            }
            else {
                if (doc.length == 0) {
                    res.status(401);
                    res.send('Usuario no autenticado');
                    return;
                }
                else {
                    next();
                }
            }
        });
    }
    else {
        return res.status(401).send("Usuario no autenticado");
    }
}

app.listen(port, () => {
    console.log("Aplicacion corriendo en puerto " + port);
});
